package HandsOn;

public class Person {
	private String name;
	private String contactNum;
	
	public void setName(String n) {
		this.name = n;
	}
	public String getName() {
		return name;
	}
	
	public void setContactNum(String c) {
		this.contactNum = c;
	}
	public String getContactNum() {
		return contactNum;
	}

}